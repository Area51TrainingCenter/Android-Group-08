package com.nhaarman.listviewanimations;

import android.widget.AbsListView;

public interface ListViewSetter {

    void setAbsListView(AbsListView listView);
}
