package com.area51.sqlite;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.area51.adapters.ResultadosAdapter;
import com.area51.models.ResultadoModel;

public class DBResultados {

	DBHelper dbhelper;
	Context context;

	public DBResultados(Context context) {
		super();
		dbhelper = new DBHelper(context);
		this.context = context;
	}

	public void insertRows(String json) {

		SQLiteDatabase query = dbhelper.getWritableDatabase();

		// Eliminamos los registros
		String sql = "DELETE FROM " + DBHelper.TABLE_RESULTADO;
		query.execSQL(sql);

		// Hacemos el insert en base al json recibido

		try {

			JSONArray data = new JSONArray(json);
			int total = data.length();
			JSONObject item;

			for (int i = 0; i < total; i++) {

				item = (JSONObject) data.get(i);

				ContentValues values = new ContentValues();

				values.put(DBHelper.CR_ID, item.getString("id"));
				values.put(DBHelper.CR_COUNTRY, item.getString("country"));
				values.put(DBHelper.CR_ALTERNATE_NAME,
						item.getString("alternate_name"));
				values.put(DBHelper.CR_FIFA_CODE, item.getString("fifa_code"));
				values.put(DBHelper.CR_GROUP_ID, item.getString("group_id"));
				values.put(DBHelper.CR_GROUP_LETTER,
						item.getString("group_letter"));
				values.put(DBHelper.CR_WINS, item.getString("wins"));
				values.put(DBHelper.CR_DRAWS, item.getString("draws"));
				values.put(DBHelper.CR_LOSSES, item.getString("losses"));
				values.put(DBHelper.CR_GAMES_PLAYED,
						item.getString("games_played"));
				values.put(DBHelper.CR_POINTS, item.getString("points"));
				values.put(DBHelper.CR_GOALS_FOR, item.getString("goals_for"));
				values.put(DBHelper.CR_GOALS_AGAINST,
						item.getString("goals_against"));
				values.put(DBHelper.CR_GOAL_DIFFERENTIAL,
						item.getString("goal_differential"));

				// Insertamos la data
				query.insert(DBHelper.TABLE_RESULTADO, null, values);

			}

		} catch (JSONException e) {

			e.printStackTrace();
		}

	}

	public ResultadosAdapter selectRows() {

		SQLiteDatabase query = dbhelper.getReadableDatabase();

		ResultadosAdapter adapter = new ResultadosAdapter(context);

		String sql = "SELECT * FROM " + DBHelper.TABLE_RESULTADO;

		Cursor cursor = query.rawQuery(sql, null);

		if (cursor.moveToFirst()) {

			do {
				
				//Asignamos los datos al adapter

				ResultadoModel model = new ResultadoModel();
				model.setCountryR( cursor.getString(DBHelper.CR_COUNTRY_INDEX) );
				model.setFifa_codeR( cursor.getString(DBHelper.CR_FIFA_CODE_INDEX) );

				model.setGroup_letterR( cursor.getString(DBHelper.CR_GROUP_LETTER_INDEX) );
				model.setWinsR( cursor.getString(DBHelper.CR_WINS_INDEX) );
				model.setDrawsR( cursor.getString(DBHelper.CR_DRAWS_INDEX) );
				model.setLossesR( cursor.getString(DBHelper.CR_LOSSES_INDEX ) );
				
				// Agregamos al adapter
				adapter.add(model);

			} while (cursor.moveToNext());

		}

		return adapter;
	}
	
	
	
	
	

	public ArrayList<String> selectData() {

		ArrayList<String> lista = new ArrayList<String>();

		return lista;

	}

}