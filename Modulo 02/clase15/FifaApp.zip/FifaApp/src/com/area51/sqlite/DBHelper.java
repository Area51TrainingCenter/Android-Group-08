package com.area51.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

	public static String DB_NAME = "fifaapp.db";
	public static int DB_VERSION = 1;

	// PARA LA TABLA RESULTADOS
	public static String TABLE_RESULTADO = "resultado";
	public static String CR_ID = "id";
	public static String CR_COUNTRY = "country";
	public static String CR_ALTERNATE_NAME = "alternate_name";
	public static String CR_FIFA_CODE = "fifa_code";
	public static String CR_GROUP_ID = "group_id";
	public static String CR_GROUP_LETTER = "group_letter";
	public static String CR_WINS = "wins";
	public static String CR_DRAWS = "draws";
	public static String CR_LOSSES = "losses";
	public static String CR_GAMES_PLAYED = "games_played";
	public static String CR_POINTS = "points";
	public static String CR_GOALS_FOR = "goals_for";
	public static String CR_GOALS_AGAINST = "goals_against";
	public static String CR_GOAL_DIFFERENTIAL = "goal_differential";

	// PARA LAS COLUMNAS
	public static int CR_ID_INDEX = 0;
	public static int CR_COUNTRY_INDEX = 1;
	public static int CR_ALTERNATE_NAME_INDEX = 2;
	public static int CR_FIFA_CODE_INDEX = 3;
	public static int CR_GROUP_ID_INDEX = 4;
	public static int CR_GROUP_LETTER_INDEX = 5;
	public static int CR_WINS_INDEX = 6;
	public static int CR_DRAWS_INDEX = 7;
	public static int CR_LOSSES_INDEX = 8;
	public static int CR_GAMES_PLAYED_INDEX = 9;
	public static int CR_POINTS_INDEX = 10;
	public static int CR_GOALS_FOR_INDEX = 11;
	public static int CR_GOALS_AGAINST_INDEX = 12;
	public static int CR_GOAL_DIFFERENTIAL_INDEX = 13;

	public DBHelper(Context context) {
		super(context, DB_NAME, null, DB_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {

		String SQL_RESULTS = "CREATE TABLE " + TABLE_RESULTADO + " (" + CR_ID
				+ " INTEGER PRIMARY KEY , " + CR_COUNTRY + " text , "
				+ CR_ALTERNATE_NAME + " text, " + CR_FIFA_CODE + " text, "
				+ CR_GROUP_ID + " text, " + CR_GROUP_LETTER + " text, "
				+ CR_WINS + " text, " + CR_DRAWS + " text, " + CR_LOSSES
				+ " text, " + CR_GAMES_PLAYED + " text, " + CR_POINTS
				+ " text, " + CR_GOALS_FOR + " text, " + CR_GOALS_AGAINST
				+ " text, " + CR_GOAL_DIFFERENTIAL + " text  )";

		Log.d("", "sql_resultado: " + SQL_RESULTS);

		db.execSQL(SQL_RESULTS);

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

		db.execSQL("drop table if exists " + TABLE_RESULTADO);
		onCreate(db);

	}

}
