package com.area51.fragments;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.area51.adapters.ResultadosAdapter;
import com.area51.fifaapp.R;
import com.area51.models.ResultadoModel;
import com.area51.sqlite.DBResultados;
import com.area51.utils.NetworkApp;
import com.area51.utils.RESTClient;
import com.nhaarman.listviewanimations.swinginadapters.prepared.SwingBottomInAnimationAdapter;

public class ResultadoFragment extends ListFragment implements
		OnRefreshListener {

	ResultadosAdapter adapter;
	NetworkApp network;
	SwingBottomInAnimationAdapter sbiaa;

	LinearLayout progreso;
	SwipeRefreshLayout swiperefresh;
	DBResultados dbresultados;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View v = inflater.inflate(R.layout.fragment_resultados, container,
				false);

		progreso = (LinearLayout) v.findViewById(R.id.progreso);
		swiperefresh  = (SwipeRefreshLayout) v.findViewById(R.id.swiperefresh);

		return v;

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);
		
		dbresultados = new DBResultados(getActivity());
		
		
		swiperefresh.setOnRefreshListener(this);
		swiperefresh
		.setColorSchemeResources(android.R.color.holo_blue_dark,
				android.R.color.holo_orange_light,
				android.R.color.holo_green_dark,
				android.R.color.holo_red_light);		
		
		network = new NetworkApp(getActivity());

		if (network.getNetwork()) {
			// lamamos al api
			// y el resultado
			// lo guardamos en sqlite
			onRefresh();
		} else {
			// sqlite
			CargaDatosSqlite();
		}

	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {

		super.onListItemClick(l, v, position, id);

	}
	

	public void CargaDatosSqlite() {
				
		adapter = new ResultadosAdapter(getActivity());
		adapter = dbresultados.selectRows();

		//Asignamos la animaci�n		
		sbiaa = new SwingBottomInAnimationAdapter(
				new SwingBottomInAnimationAdapter(adapter));

		sbiaa.setInitialDelayMillis(300);
		sbiaa.setAbsListView(getListView());

		setListAdapter(sbiaa);

	}	

	public void CargaDatos(String json) {
		
		//Guardamos los datos en sqlite
		dbresultados.insertRows(json);
				
		adapter = new ResultadosAdapter(getActivity());
		adapter = dbresultados.selectRows();

		//Asignamos la animaci�n		
		sbiaa = new SwingBottomInAnimationAdapter(
				new SwingBottomInAnimationAdapter(adapter));

		sbiaa.setInitialDelayMillis(300);
		sbiaa.setAbsListView(getListView());

		setListAdapter(sbiaa);

	}

	class RequestResultado extends AsyncTask<String, Void, String> {

		// private ProgressDialog dialogo;

		@Override
		protected void onCancelled() {

			super.onCancelled();

		}

		@Override
		protected void onPreExecute() {

			super.onPreExecute();

			// dialogo = new ProgressDialog(getActivity());
			// dialogo.setMessage(getResources().getString(R.string.cargando));
			// dialogo.setCancelable(false);
			// dialogo.show();

		}

		@Override
		protected String doInBackground(String... params) {

			String resultado = "";

			for (String url : params) {

				try {
					resultado = RESTClient.connectAndReturnResponse(url);
				} catch (Exception e) {

				}

			}

			return resultado;
		}

		@Override
		protected void onPostExecute(String result) {

			super.onPostExecute(result);

			// dialogo.dismiss();
			Log.d("app", "" + result);

			// Guardar los datos en sqlite

			swiperefresh.setRefreshing(false);
			progreso.setVisibility(View.GONE );
			CargaDatos(result);
			
		}
	}

	@Override
	public void onRefresh() {

		if (network.getNetwork()) {
			new RequestResultado()
				.execute("http://worldcup.sfg.io/teams/results");
		} else {
			// sqlite
			CargaDatosSqlite();
		}
		
	}

}
