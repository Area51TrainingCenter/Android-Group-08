package com.area51.grupo08.models;

public class ProgramModel {

	protected int idProgram;
	protected String nameProgram;
	protected String pathProgram;

	public int getIdProgram() {
		return idProgram;
	}

	public void setIdProgram(int idProgram) {
		this.idProgram = idProgram;
	}

	public String getNameProgram() {
		return nameProgram;
	}

	public void setNameProgram(String nameProgram) {
		this.nameProgram = nameProgram;
	}

	public String getPathProgram() {
		return pathProgram;
	}

	public void setPathProgram(String pathProgram) {
		this.pathProgram = pathProgram;
	}

}
