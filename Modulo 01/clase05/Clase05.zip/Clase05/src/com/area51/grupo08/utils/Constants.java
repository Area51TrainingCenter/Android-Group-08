package com.area51.grupo08.utils;

import java.util.ArrayList;

import com.area51.grupo08.models.ProgramModel;

public class Constants {

	public static ArrayList<ProgramModel> ArrayProgram;

}
