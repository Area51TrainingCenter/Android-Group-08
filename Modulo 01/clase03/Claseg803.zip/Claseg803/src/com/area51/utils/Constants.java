package com.area51.utils;

import java.util.ArrayList;

import com.area51.models.ImageModel;

public class Constants {

	public static ArrayList<ImageModel>lista;
	
}
