package com.area51.models;

public class EquipoModel {

	protected int idEquipo;
	protected String nombreEquipo;
	protected String detalleEquipo;
	protected int imagenEquipo;

	public int getIdEquipo() {
		return idEquipo;
	}

	public void setIdEquipo(int idEquipo) {
		this.idEquipo = idEquipo;
	}

	public String getNombreEquipo() {
		return nombreEquipo;
	}

	public void setNombreEquipo(String nombreEquipo) {
		this.nombreEquipo = nombreEquipo;
	}

	public String getDetalleEquipo() {
		return detalleEquipo;
	}

	public void setDetalleEquipo(String detalleEquipo) {
		this.detalleEquipo = detalleEquipo;
	}

	public int getImagenEquipo() {
		return imagenEquipo;
	}

	public void setImagenEquipo(int imagenEquipo) {
		this.imagenEquipo = imagenEquipo;
	}

}
