package com.area51.utils;

import java.util.ArrayList;

import com.area51.models.EquipoModel;

public class Constants {

	public static int imagen = 0;
	public static String nombre = "";
	public static String detalle = "";
	public static ArrayList<EquipoModel> arregloEquipo;

}
